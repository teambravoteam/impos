package com.teambravo.impos.sale.service;

import java.util.List;

import com.teambravo.impos.sale.dao.SaleDao;

public class SaleService {
	private SaleDao saleDao = new SaleDao();

	public SaleService() {

	}

	public List<Sale> findAllSale() {
		return saleDao.findAllSale();
	}
}
