package com.teambravo.impos.sale.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.teambravo.impos.init.domain.DataSource;
import com.teambravo.impos.init.service.NamingService;
import com.teambravo.impos.sale.service.Sale;

public class SaleDao {
	NamingService nameService = NamingService.getInstance();
	DataSource data = (DataSource) nameService.getAttribute("dataSource");

	public List<Sale> findAllSale() {
		String sql = "SELECT * FROM Sale";
		List<Sale> saleList = new ArrayList<>(); // List 배열로 데이터를 받기 위해 배열 생성
		try {
			Connection con = data.getConnection(); // DB와 연결
			PreparedStatement pstmt = con.prepareStatement(sql); // con에 sql을 입력하는 것을 pstmt에 담음
			ResultSet rs = pstmt.executeQuery();
			try {
				while (rs.next()) { // 해당 테이블에서 데이터를 찾으면 true, 없으면 false
					Sale sale = new Sale();
					sale.setSaCode(rs.getString("saCode"));
					sale.setSaName(rs.getString("passwd"));
					sale.setSaPrice(rs.getDouble("saPrice"));
					sale.setSaCategory(rs.getString("saCategory"));
					sale.setSaCount(rs.getInt("saCount"));
					sale.setRegDate(rs.getDate("regDate"));
					saleList.add(sale);
				}
			} finally {
				data.close(rs, pstmt, con);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return saleList; // List 에 결과값을 받음
	}
}
